@file:OptIn(ExperimentalFoundationApi::class)

package com.mylauncher.ios

import android.content.Context
import android.os.BatteryManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

val ROW_H = 96.dp
const val COLS = 4
private val ICON = 60.dp

private val LabelStyle = TextStyle(
    fontSize = 11.sp,
    color = Color.White,
    shadow = Shadow(Color(0x99000000), Offset(0f, 1f), 4f)
)

// ------------------------------------------------------------
// Ilova va papka katakchalari
// ------------------------------------------------------------

@Composable
fun AppCell(
    app: AppItem,
    iconSize: Dp,
    showLabel: Boolean = true,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.88f else 1f, label = "press")
    val haptic = LocalHapticFeedback.current
    Column(
        Modifier
            .scale(scale)
            .combinedClickable(
                interactionSource = src,
                indication = null,
                onClick = onClick,
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongClick()
                }
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier
                .size(iconSize)
                .clip(RoundedCornerShape(iconSize * 0.225f))
        )
        if (showLabel) {
            Spacer(Modifier.height(5.dp))
            Text(
                app.label,
                style = LabelStyle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.width(iconSize + 18.dp)
            )
        }
    }
}

@Composable
fun FolderTile(
    folder: FolderItem,
    apps: List<AppItem>,
    iconSize: Dp,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.88f else 1f, label = "press")
    val haptic = LocalHapticFeedback.current
    val mini = iconSize * 0.22f
    val gap = iconSize * 0.04f
    Column(
        Modifier
            .scale(scale)
            .combinedClickable(
                interactionSource = src,
                indication = null,
                onClick = onClick,
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongClick()
                }
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(iconSize)
                .clip(RoundedCornerShape(iconSize * 0.225f))
                .background(Color(0x59FFFFFF)),
            contentAlignment = Alignment.Center
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(gap)) {
                apps.take(9).chunked(3).forEach { r ->
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        r.forEach { a ->
                            Image(
                                bitmap = a.icon,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(mini)
                                    .clip(RoundedCornerShape(mini * 0.25f))
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(
            folder.name,
            style = LabelStyle,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.width(iconSize + 18.dp)
        )
    }
}

// ------------------------------------------------------------
// Vidjet, nuqtalar, qidiruv tugmasi, dock, pastki chiziq
// ------------------------------------------------------------

@Composable
fun WidgetCard(modifier: Modifier) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    var battery by remember { mutableIntStateOf(-1) }
    LaunchedEffect(Unit) {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        while (true) {
            now = Date()
            battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            delay(20_000)
        }
    }
    val time = remember(now) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(now) }
    val date = remember(now) { SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now) }
    Box(
        modifier
            .clip(RoundedCornerShape(26.dp))
            .background(Color(0x4DFFFFFF))
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Column(Modifier.align(Alignment.CenterStart)) {
            Text(time, color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Light)
            Text(date, color = Color.White.copy(alpha = 0.85f), fontSize = 15.sp)
        }
        if (battery >= 0) {
            Column(Modifier.align(Alignment.CenterEnd), horizontalAlignment = Alignment.End) {
                Text("$battery%", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Medium)
                Text("Batareya", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun PageDots(count: Int, current: Int) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(24.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(count) { i ->
            Box(
                Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = if (i == current) 1f else 0.4f))
            )
        }
    }
}

@Composable
fun SearchPill(visible: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(44.dp),
        contentAlignment = Alignment.Center
    ) {
        if (visible) {
            Row(
                Modifier
                    .clip(CircleShape)
                    .background(Color(0x40FFFFFF))
                    .clickable { onClick() }
                    .padding(horizontal = 24.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Search, null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Qidirish", color = Color.White, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun Dock(apps: List<AppItem>, onClick: (AppItem) -> Unit, onLong: (AppItem) -> Unit) {
    Row(
        Modifier
            .padding(horizontal = 14.dp)
            .fillMaxWidth()
            .height(88.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(Color(0x40FFFFFF)),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        apps.forEach { app ->
            AppCell(app, 58.dp, false, { onClick(app) }, { onLong(app) })
        }
    }
}

/** Pastdagi chiziq: tepaga surilsa yoki bosilsa bosh sahifaga qaytadi. */
@Composable
fun HomeIndicator(onHome: () -> Unit) {
    val threshold = with(LocalDensity.current) { 40.dp.toPx() }
    val cb by rememberUpdatedState(onHome)
    Box(
        Modifier
            .fillMaxWidth()
            .height(30.dp)
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = 0f },
                    onDragEnd = { if (acc < -threshold) cb() },
                    onVerticalDrag = { _, d -> acc += d }
                )
            }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { cb() },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .width(136.dp)
                .height(5.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.92f))
        )
    }
}

/** Ekran chetidan suriladigan "orqaga" ishorasi: chap va o'ng chetda. */
@Composable
fun EdgeBackGestures(onBack: () -> Unit) {
    val density = LocalDensity.current
    val threshold = with(density) { 72.dp.toPx() }
    val bubble = with(density) { 44.dp.toPx() }
    val margin = with(density) { 14.dp.toPx() }
    val cb by rememberUpdatedState(onBack)
    var left by remember { mutableFloatStateOf(0f) }
    var right by remember { mutableFloatStateOf(0f) }

    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .fillMaxHeight(0.55f)
                .width(18.dp)
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragStart = { left = 0f },
                        onDragEnd = {
                            if (left >= threshold) cb()
                            left = 0f
                        },
                        onDragCancel = { left = 0f },
                        onHorizontalDrag = { change, amount ->
                            change.consume()
                            left = (left + amount).coerceIn(0f, threshold)
                        }
                    )
                }
        )
        Box(
            Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight(0.55f)
                .width(18.dp)
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragStart = { right = 0f },
                        onDragEnd = {
                            if (right >= threshold) cb()
                            right = 0f
                        },
                        onDragCancel = { right = 0f },
                        onHorizontalDrag = { change, amount ->
                            change.consume()
                            right = (right - amount).coerceIn(0f, threshold)
                        }
                    )
                }
        )
        if (left > 0f) {
            val p = left / threshold
            BackBubble(
                p, false,
                Modifier
                    .align(Alignment.CenterStart)
                    .offset { IntOffset((-bubble + p * (bubble + margin)).roundToInt(), 0) }
            )
        }
        if (right > 0f) {
            val p = right / threshold
            BackBubble(
                p, true,
                Modifier
                    .align(Alignment.CenterEnd)
                    .offset { IntOffset((bubble - p * (bubble + margin)).roundToInt(), 0) }
            )
        }
    }
}

@Composable
private fun BackBubble(progress: Float, mirrored: Boolean, modifier: Modifier) {
    val ready = progress >= 1f
    Box(
        modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(if (ready) Color.White else Color(0xCC3A3A3C)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.AutoMirrored.Rounded.ArrowBack,
            contentDescription = null,
            tint = if (ready) Color.Black else Color.White,
            modifier = Modifier
                .size(22.dp)
                .graphicsLayer { rotationZ = if (mirrored) 180f else 0f }
        )
    }
}

// ------------------------------------------------------------
// Sahifalar
// ------------------------------------------------------------

@Composable
fun HomePage(
    entries: List<HomeEntry>,
    showWidget: Boolean,
    onApp: (AppItem) -> Unit,
    onFolder: (FolderItem) -> Unit,
    onAppLong: (AppItem) -> Unit,
    onFolderLong: (FolderItem) -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 6.dp)
    ) {
        if (showWidget) {
            WidgetCard(
                Modifier
                    .fillMaxWidth()
                    .height(ROW_H * 2)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
        entries.chunked(COLS).forEach { row ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(ROW_H)
            ) {
                row.forEach { e ->
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(top = 6.dp),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        when (e) {
                            is HomeEntry.App ->
                                AppCell(e.app, ICON, true, { onApp(e.app) }, { onAppLong(e.app) })
                            is HomeEntry.Folder ->
                                FolderTile(e.folder, e.apps, ICON, { onFolder(e.folder) }, { onFolderLong(e.folder) })
                        }
                    }
                }
                repeat(COLS - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun LibraryPage(
    apps: List<AppItem>,
    onSearch: () -> Unit,
    onOpenGroup: (String, List<AppItem>) -> Unit,
    onLaunch: (AppItem) -> Unit,
    onLong: (AppItem) -> Unit
) {
    val groups = remember(apps) {
        apps.groupBy { groupName(it.category) }
            .toList()
            .sortedWith(
                compareBy<Pair<String, List<AppItem>>>({ it.first == OTHER_GROUP }, { -it.second.size })
            )
    }
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Text(
            "Ilovalar kutubxonasi",
            color = Color.White,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp, bottom = 10.dp)
        )
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0x40FFFFFF))
                .clickable { onSearch() }
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Search, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Qidirish", color = Color.White.copy(alpha = 0.8f), fontSize = 15.sp)
        }
        Spacer(Modifier.height(14.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            items(groups) { g ->
                GroupCard(g.first, g.second, onOpenGroup, onLaunch, onLong)
            }
        }
    }
}

@Composable
private fun GroupCard(
    name: String,
    list: List<AppItem>,
    onOpenGroup: (String, List<AppItem>) -> Unit,
    onLaunch: (AppItem) -> Unit,
    onLong: (AppItem) -> Unit
) {
    Column {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0x40FFFFFF))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            for (r in 0..1) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    for (c in 0..1) {
                        val idx = r * 2 + c
                        Box(Modifier.size(52.dp)) {
                            if (idx < 3 || list.size <= 4) {
                                list.getOrNull(idx)?.let { a ->
                                    AppCell(a, 52.dp, false, { onLaunch(a) }, { onLong(a) })
                                }
                            } else {
                                Box(
                                    Modifier
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0x33FFFFFF))
                                        .clickable { onOpenGroup(name, list) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        list.drop(3).take(4).chunked(2).forEach { pair ->
                                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                                pair.forEach { a ->
                                                    Image(
                                                        bitmap = a.icon,
                                                        contentDescription = null,
                                                        modifier = Modifier
                                                            .size(19.dp)
                                                            .clip(RoundedCornerShape(5.dp))
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Text(
            name,
            color = Color.White,
            fontSize = 12.sp,
            modifier = Modifier
                .clickable { onOpenGroup(name, list) }
                .padding(top = 6.dp, start = 6.dp, bottom = 2.dp)
        )
    }
}

// ------------------------------------------------------------
// Qoplamalar (papka, qidiruv), menyu, dialoglar
// ------------------------------------------------------------

sealed class Overlay {
    data class Folder(val id: String) : Overlay()
    data class Category(val title: String, val apps: List<AppItem>) : Overlay()
}

@Composable
fun GroupOverlay(
    title: String,
    apps: List<AppItem>,
    onRename: (() -> Unit)?,
    onClose: () -> Unit,
    onLaunch: (AppItem) -> Unit,
    onLong: (AppItem) -> Unit
) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xA6000000))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClose() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .padding(horizontal = 22.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(34.dp))
                .background(Color(0xD93A3A3C))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { }
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                title,
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clickable(enabled = onRename != null) { onRename?.invoke() }
                    .padding(8.dp)
            )
            Spacer(Modifier.height(8.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.heightIn(max = 440.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(apps, key = { it.pkg }) { a ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        AppCell(a, 62.dp, true, { onLaunch(a) }, { onLong(a) })
                    }
                }
            }
        }
    }
}

@Composable
fun SearchOverlay(apps: List<AppItem>, onClose: () -> Unit, onLaunch: (AppItem) -> Unit) {
    var q by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    val results = remember(q, apps) {
        if (q.isBlank()) apps else apps.filter { it.label.contains(q.trim(), ignoreCase = true) }
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xE60B0B0C))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { }
            .statusBarsPadding()
            .imePadding()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextField(
                value = q,
                onValueChange = { q = it },
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focus),
                singleLine = true,
                placeholder = { Text("Ilovalarni qidirish") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                shape = RoundedCornerShape(16.dp),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedContainerColor = Color(0x33FFFFFF),
                    unfocusedContainerColor = Color(0x33FFFFFF)
                )
            )
            TextButton(onClick = onClose) { Text("Bekor") }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn {
            items(results, key = { it.pkg }) { a ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onLaunch(a) }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        bitmap = a.icon,
                        contentDescription = null,
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                    Spacer(Modifier.width(14.dp))
                    Text(a.label, color = Color.White, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
private fun MenuRow(icon: ImageVector, text: String, tint: Color = Color.White, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(14.dp))
        Text(text, color = tint, fontSize = 16.sp)
    }
}

@Composable
fun AppMenu(
    app: AppItem,
    inFolder: Boolean,
    inDock: Boolean,
    dockFull: Boolean,
    folders: List<FolderItem>,
    onDismiss: () -> Unit,
    onNewFolder: () -> Unit,
    onAddToFolder: (FolderItem) -> Unit,
    onRemoveFromFolder: () -> Unit,
    onToggleDock: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 520.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xF2262628))
                .verticalScroll(rememberScrollState())
                .padding(vertical = 8.dp)
        ) {
            Row(
                Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    bitmap = app.icon,
                    contentDescription = null,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(9.dp))
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    app.label,
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            HorizontalDivider(color = Color(0x33FFFFFF))
            MenuRow(Icons.Rounded.CreateNewFolder, "Yangi papka yaratish") { onNewFolder() }
            folders.forEach { f ->
                MenuRow(Icons.Rounded.Folder, "«${f.name}» papkasiga qo'shish") { onAddToFolder(f) }
            }
            if (inFolder) {
                MenuRow(Icons.Rounded.Close, "Papkadan chiqarish") { onRemoveFromFolder() }
            }
            if (inDock) {
                MenuRow(Icons.Rounded.PushPin, "Dockdan olib tashlash") { onToggleDock() }
            } else if (!dockFull) {
                MenuRow(Icons.Rounded.PushPin, "Dockka qo'yish") { onToggleDock() }
            }
            MenuRow(Icons.Rounded.Info, "Ilova haqida") { onInfo() }
            MenuRow(Icons.Rounded.Delete, "O'chirish", Color(0xFFFF453A)) { onUninstall() }
        }
    }
}

@Composable
fun TextInputDialog(
    title: String,
    initial: String,
    confirmText: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(text.trim()) }) { Text(confirmText) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } }
    )
}
