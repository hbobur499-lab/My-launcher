package com.mylauncher.ios

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private val CHROME_H = 224.dp

fun paginate(entries: List<HomeEntry>, rows: Int): List<List<HomeEntry>> {
    val first = (rows - 2).coerceAtLeast(1) * COLS
    val per = rows * COLS
    val pages = mutableListOf<List<HomeEntry>>()
    pages.add(entries.take(first))
    var rest = entries.drop(first)
    while (rest.isNotEmpty()) {
        pages.add(rest.take(per))
        rest = rest.drop(per)
    }
    return pages
}

fun launchApp(ctx: Context, app: AppItem) {
    try {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(app.pkg, app.activity)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, "Ilovani ochib bo'lmadi", Toast.LENGTH_SHORT).show()
    }
}

fun openAppInfo(ctx: Context, pkg: String) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        Toast.makeText(ctx, "Ochib bo'lmadi", Toast.LENGTH_SHORT).show()
    }
}

fun uninstallApp(ctx: Context, pkg: String) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        Toast.makeText(ctx, "O'chirib bo'lmadi", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun LauncherScreen(vm: LauncherVM) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val swipePx = with(LocalDensity.current) { 70.dp.toPx() }

    val apps = vm.apps
    val folders = vm.folders
    val dock = vm.dock
    val byPkg = remember(apps) { apps.associateBy { it.pkg } }
    val dockApps = remember(dock, byPkg) { dock.mapNotNull { byPkg[it] } }
    val entries = remember(apps, folders, dock, byPkg) {
        val hidden = (folders.flatMap { it.pkgs } + dock).toSet()
        val list = mutableListOf<HomeEntry>()
        folders.forEach { f -> list.add(HomeEntry.Folder(f, f.pkgs.mapNotNull { byPkg[it] })) }
        apps.forEach { a -> if (a.pkg !in hidden) list.add(HomeEntry.App(a)) }
        list.toList()
    }

    var menuApp by remember { mutableStateOf<AppItem?>(null) }
    var overlay by remember { mutableStateOf<Overlay?>(null) }
    var showSearch by remember { mutableStateOf(false) }
    var newFolderFor by remember { mutableStateOf<AppItem?>(null) }
    var renameFolderId by remember { mutableStateOf<String?>(null) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
        val botInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
        val avail = maxHeight - topInset - botInset - CHROME_H
        val rows = (avail / ROW_H).toInt().coerceIn(4, 7)
        val pages = remember(entries, rows) { paginate(entries, rows) }
        val pager = rememberPagerState(pageCount = { pages.size + 1 })

        val goHome: () -> Unit = {
            menuApp = null
            overlay = null
            showSearch = false
            newFolderFor = null
            renameFolderId = null
            scope.launch { pager.animateScrollToPage(0) }
        }
        val goBack: () -> Unit = {
            when {
                menuApp != null -> menuApp = null
                overlay != null -> overlay = null
                showSearch -> showSearch = false
                pager.currentPage > 0 -> scope.launch { pager.animateScrollToPage(pager.currentPage - 1) }
                else -> {}
            }
        }
        val startApp: (AppItem) -> Unit = { a ->
            overlay = null
            showSearch = false
            launchApp(ctx, a)
        }

        BackHandler { goBack() }
        LaunchedEffect(vm.homeTick) { if (vm.homeTick > 0) goHome() }

        Column(Modifier.fillMaxSize()) {
            Spacer(Modifier.windowInsetsTopHeight(WindowInsets.statusBars))

            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        var acc = 0f
                        detectVerticalDragGestures(
                            onDragStart = { acc = 0f },
                            onDragEnd = { if (acc > swipePx) showSearch = true },
                            onVerticalDrag = { _, d -> acc += d }
                        )
                    }
            ) {
                HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                    if (page < pages.size) {
                        HomePage(
                            entries = pages[page],
                            showWidget = page == 0,
                            onApp = startApp,
                            onFolder = { f -> overlay = Overlay.Folder(f.id) },
                            onAppLong = { menuApp = it },
                            onFolderLong = { f -> renameFolderId = f.id }
                        )
                    } else {
                        LibraryPage(
                            apps = apps,
                            onSearch = { showSearch = true },
                            onOpenGroup = { t, l -> overlay = Overlay.Category(t, l) },
                            onLaunch = startApp,
                            onLong = { menuApp = it }
                        )
                    }
                }
            }

            SearchPill(visible = pager.currentPage < pages.size) { showSearch = true }
            PageDots(count = pages.size + 1, current = pager.currentPage)
            Dock(dockApps, onClick = startApp, onLong = { menuApp = it })
            Spacer(Modifier.height(8.dp))
            HomeIndicator(onHome = goHome)
            Spacer(Modifier.windowInsetsBottomHeight(WindowInsets.navigationBars))
        }

        // ---- qoplamalar ----
        overlay?.let { ov ->
            when (ov) {
                is Overlay.Folder -> {
                    val f = folders.firstOrNull { it.id == ov.id }
                    if (f == null) {
                        LaunchedEffect(ov) { overlay = null }
                    } else {
                        GroupOverlay(
                            title = f.name,
                            apps = f.pkgs.mapNotNull { byPkg[it] },
                            onRename = { renameFolderId = f.id },
                            onClose = { overlay = null },
                            onLaunch = startApp,
                            onLong = { menuApp = it }
                        )
                    }
                }
                is Overlay.Category -> GroupOverlay(
                    title = ov.title,
                    apps = ov.apps,
                    onRename = null,
                    onClose = { overlay = null },
                    onLaunch = startApp,
                    onLong = { menuApp = it }
                )
            }
        }

        if (showSearch) {
            SearchOverlay(apps = apps, onClose = { showSearch = false }, onLaunch = startApp)
        }

        EdgeBackGestures(onBack = goBack)

        // ---- dialoglar ----
        menuApp?.let { a ->
            val folderOf = folders.firstOrNull { a.pkg in it.pkgs }
            AppMenu(
                app = a,
                inFolder = folderOf != null,
                inDock = a.pkg in dock,
                dockFull = dock.size >= 4,
                folders = folders.filter { it.id != folderOf?.id },
                onDismiss = { menuApp = null },
                onNewFolder = { newFolderFor = a; menuApp = null },
                onAddToFolder = { f -> vm.addToFolder(f.id, a.pkg); menuApp = null },
                onRemoveFromFolder = { vm.removeFromFolder(a.pkg); menuApp = null },
                onToggleDock = { vm.toggleDock(a.pkg); menuApp = null },
                onInfo = { openAppInfo(ctx, a.pkg); menuApp = null },
                onUninstall = { uninstallApp(ctx, a.pkg); menuApp = null }
            )
        }

        newFolderFor?.let { a ->
            TextInputDialog(
                title = "Yangi papka",
                initial = "Papka",
                confirmText = "Yaratish",
                onDismiss = { newFolderFor = null },
                onConfirm = { name ->
                    vm.createFolder(name, a.pkg)
                    newFolderFor = null
                }
            )
        }

        renameFolderId?.let { id ->
            val f = folders.firstOrNull { it.id == id }
            if (f != null) {
                TextInputDialog(
                    title = "Papka nomi",
                    initial = f.name,
                    confirmText = "Saqlash",
                    onDismiss = { renameFolderId = null },
                    onConfirm = { name ->
                        vm.renameFolder(id, name)
                        renameFolderId = null
                    }
                )
            }
        }
    }
}
