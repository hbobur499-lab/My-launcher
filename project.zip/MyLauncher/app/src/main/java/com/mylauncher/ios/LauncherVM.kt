package com.mylauncher.ios

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

const val OTHER_GROUP = "Boshqalar"

data class AppItem(
    val label: String,
    val pkg: String,
    val activity: String,
    val category: Int,
    val icon: ImageBitmap
)

data class FolderItem(val id: String, val name: String, val pkgs: List<String>)

sealed class HomeEntry {
    data class App(val app: AppItem) : HomeEntry()
    data class Folder(val folder: FolderItem, val apps: List<AppItem>) : HomeEntry()
}

fun groupName(category: Int): String = when (category) {
    ApplicationInfo.CATEGORY_SOCIAL -> "Ijtimoiy"
    ApplicationInfo.CATEGORY_GAME -> "O'yinlar"
    ApplicationInfo.CATEGORY_AUDIO,
    ApplicationInfo.CATEGORY_VIDEO,
    ApplicationInfo.CATEGORY_IMAGE -> "Media va ko'ngilochar"
    ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Mahsuldorlik"
    ApplicationInfo.CATEGORY_NEWS,
    ApplicationInfo.CATEGORY_MAPS -> "Yangiliklar va xaritalar"
    else -> OTHER_GROUP
}

class LauncherVM(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    var apps by mutableStateOf<List<AppItem>>(emptyList())
        private set
    var folders by mutableStateOf(loadFolders())
        private set
    var dock by mutableStateOf(loadDock())
        private set
    var homeTick by mutableIntStateOf(0)

    init {
        reload()
    }

    fun reload() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.Default) { queryApps() }
            apps = list
            if (list.isNotEmpty()) {
                val known = list.map { it.pkg }.toSet()
                dock = if (!prefs.contains("dock")) defaultDock(list) else dock.filter { it in known }
                folders = folders
                    .map { f -> f.copy(pkgs = f.pkgs.filter { it in known }) }
                    .filter { it.pkgs.isNotEmpty() }
                saveDock()
                saveFolders()
            }
        }
    }

    // ---------- papkalar va dock ----------

    private fun detachFromFolders(pkg: String) {
        folders = folders
            .map { it.copy(pkgs = it.pkgs - pkg) }
            .filter { it.pkgs.isNotEmpty() }
    }

    fun createFolder(name: String, pkg: String) {
        detachFromFolders(pkg)
        dock = dock - pkg
        folders = folders + FolderItem(UUID.randomUUID().toString(), name.ifBlank { "Papka" }, listOf(pkg))
        persist()
    }

    fun addToFolder(folderId: String, pkg: String) {
        detachFromFolders(pkg)
        dock = dock - pkg
        folders = folders.map { if (it.id == folderId) it.copy(pkgs = it.pkgs + pkg) else it }
        persist()
    }

    fun removeFromFolder(pkg: String) {
        detachFromFolders(pkg)
        persist()
    }

    fun renameFolder(folderId: String, name: String) {
        folders = folders.map { if (it.id == folderId) it.copy(name = name.ifBlank { "Papka" }) else it }
        persist()
    }

    fun toggleDock(pkg: String) {
        if (pkg in dock) {
            dock = dock - pkg
        } else if (dock.size < 4) {
            detachFromFolders(pkg)
            dock = dock + pkg
        }
        persist()
    }

    private fun persist() {
        saveFolders()
        saveDock()
    }

    private fun loadFolders(): List<FolderItem> = try {
        val arr = JSONArray(prefs.getString("folders", "[]"))
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            val p = o.getJSONArray("pkgs")
            FolderItem(o.getString("id"), o.getString("name"), List(p.length()) { p.getString(it) })
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun saveFolders() {
        val arr = JSONArray()
        folders.forEach { f ->
            arr.put(
                JSONObject()
                    .put("id", f.id)
                    .put("name", f.name)
                    .put("pkgs", JSONArray(f.pkgs))
            )
        }
        prefs.edit().putString("folders", arr.toString()).apply()
    }

    private fun loadDock(): List<String> = try {
        val arr = JSONArray(prefs.getString("dock", "[]"))
        List(arr.length()) { arr.getString(it) }
    } catch (e: Exception) {
        emptyList()
    }

    private fun saveDock() {
        prefs.edit().putString("dock", JSONArray(dock).toString()).apply()
    }

    // ---------- ilovalarni o'qish ----------

    private fun queryApps(): List<AppItem> {
        val ctx = getApplication<Application>()
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map { ri ->
                AppItem(
                    label = ri.loadLabel(pm).toString(),
                    pkg = ri.activityInfo.packageName,
                    activity = ri.activityInfo.name,
                    category = ri.activityInfo.applicationInfo.category,
                    icon = ri.loadIcon(pm).toBitmap(144, 144).asImageBitmap()
                )
            }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun defaultDock(list: List<AppItem>): List<String> {
        val pm = getApplication<Application>().packageManager
        val known = list.map { it.pkg }.toSet()
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val result = mutableListOf<String>()
        for (i in intents) {
            val p = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            if (p != null && p in known && p !in result) result.add(p)
        }
        for (a in list) {
            if (result.size >= 4) break
            if (a.pkg !in result) result.add(a.pkg)
        }
        return result.take(4)
    }
}
